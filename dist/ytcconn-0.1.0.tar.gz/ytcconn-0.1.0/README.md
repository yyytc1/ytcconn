# ytcconn

A lightweight connection and proxy manager.

Quick usage:

```python
from ytcconn import Conn, start_proxy_fetcher

# Start background proxy fetcher from a URL
start_proxy_fetcher('http://your-proxy-source.example/api/list')

c = Conn()
# Use c.get_proxy() or c.change_proxy()
```
